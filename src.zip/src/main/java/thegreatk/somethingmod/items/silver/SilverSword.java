package thegreatk.somethingmod.items.silver;

import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;

public class SilverSword extends SwordItem
{
	public SilverSword()
	{
		super(Tiers.GOLD, 0, -2.4F, new Item.Properties().tab(CreativeModeTab.TAB_COMBAT));
	}
}
