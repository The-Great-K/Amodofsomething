package thegreatk.somethingmod.recipe;

public class MetalAlloyerMenu {

}
