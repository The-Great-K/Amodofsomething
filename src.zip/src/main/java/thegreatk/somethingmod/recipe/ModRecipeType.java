package thegreatk.somethingmod.recipe;

import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeType;

public interface ModRecipeType<T extends Recipe<?>> extends RecipeType<T> {

	ModRecipeType<AlloyerRecipe> ALLOYER = register("alloyer");

	static <T extends Recipe<?>> ModRecipeType<T> register(final String recipe) {
		return Registry.register(Registry.RECIPE_TYPE, new ResourceLocation(recipe), new ModRecipeType<T>() {
			public String toString() {
				return recipe;
			}
		});
	}
}