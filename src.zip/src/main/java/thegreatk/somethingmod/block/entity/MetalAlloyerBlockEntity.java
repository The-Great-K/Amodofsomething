package thegreatk.somethingmod.block.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.BlastFurnaceMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import thegreatk.somethingmod.init.BlockEntityInit;
import thegreatk.somethingmod.recipe.ModRecipeType;

public class MetalAlloyerBlockEntity extends AbstractAlloyerBlockEntity {

	public MetalAlloyerBlockEntity(BlockPos pos, BlockState state) {
		super(BlockEntityInit.METAL_ALLOYER_BLOCK_ENTITY.get(), pos, state, ModRecipeType.ALLOYER);
	}

	protected Component getDefaultName() {
		return new TranslatableComponent("container.metal_alloyer");
	}

	protected int getBurnDuration(ItemStack stack) {
		return super.getBurnDuration(stack) / 2;
	}

	protected AbstractContainerMenu createMenu(int p_58849_, Inventory menu) {
		return new BlastFurnaceMenu(p_58849_, menu, this, this.dataAccess);
	}

}
