package thegreatk.somethingmod;

import net.minecraft.world.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import thegreatk.somethingmod.CodakidFiles.Codakid;
import thegreatk.somethingmod.items.silver.SilverSword;

@Mod(Main.MODID)
@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)

public class Main
{
    public static final String MODID = "somethingmod";
    public static final String MODNAME = "A Mod Of Something";
    public static String VERSION = "0.0.1";
    
    public static Main instance;
    
    //*********** DECLARE VARIABLES ******************
    //Silver
    public static SilverSword silverSword;
    
    public Main()
    {
        //*********** INITIALIZE MATERIALS ******************
    	
        //*********** INITIALIZE VARIABLES ******************
    	//Silver
    	silverSword = new SilverSword();
    	
    	
        //****************** REGISTER ITEMS *****************
    	//Silver
    	Codakid.registerItem(silverSword, "silver_sword");
    }
    
    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event){ Codakid.doItemRegistry(event); }
}